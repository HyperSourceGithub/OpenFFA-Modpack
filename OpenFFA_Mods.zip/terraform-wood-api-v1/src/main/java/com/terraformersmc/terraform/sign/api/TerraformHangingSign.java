package com.terraformersmc.terraform.sign.api;

import net.minecraft.util.Identifier;

public interface TerraformHangingSign extends TerraformSign {
	Identifier getGuiTexture();
}
