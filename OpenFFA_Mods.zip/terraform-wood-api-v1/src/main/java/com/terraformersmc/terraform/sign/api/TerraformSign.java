package com.terraformersmc.terraform.sign.api;

import net.minecraft.util.Identifier;

public interface TerraformSign {
	Identifier getTexture();
}
